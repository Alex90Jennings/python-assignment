diet_preferences = ["Vegan", "Vegetarian", "Halal", "Kosher", "Paleo", "Gluten-Free", "Dairy-Free", "Low-Carb", "Keto"]

employee_attributes = [ "firstName", "lastName", "email", "isFullTime", "isActive", "salary", "annualLeaveDays", "dateJoined", "dietPreferences" ]